package com.weatherapps.mystorybook

data class Story(

    val title : Int,
    val story : Int,
    val moral : Int,
    val image : Int,
    val image2 : Int

)
