package com.socialpps.myfavbuttonrecycler.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.socialpps.myfavbuttonrecycler.model.MyModel;
import com.socialpps.myfavbuttonrecycler.R;
import com.socialpps.myfavbuttonrecycler.ui.FavoriteDao;
import com.socialpps.myfavbuttonrecycler.model.FavoriteModel;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private final List<MyModel> list;
    private final FavoriteDao favoriteDao;

    public MyAdapter(List<MyModel> list, FavoriteDao favoriteDao) {
        this.list = list;
        this.favoriteDao = favoriteDao;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_layout, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        MyModel model = list.get(position);
        holder.urdu.setText(model.urdu);
        holder.english.setText(String.valueOf(model.id));
        holder.english.setText(model.english);
        holder.math.setText(model.math);

        boolean isFavorite = favoriteDao.isFavorite(model.id);
        if (isFavorite) {

            holder.iv_favorite.setImageResource(R.drawable.ic_favorite);

        } else {
            holder.iv_favorite.setImageResource(R.drawable.ic_favorite_border);
        }


        holder.iv_favorite.setOnClickListener(view -> {
            boolean isCurrentlyFavorite = favoriteDao.isFavorite(model.id);


            if (isCurrentlyFavorite) {
                favoriteDao.deleteData(model.id);
                holder.iv_favorite.setImageResource(R.drawable.ic_favorite_border);
            } else {
                favoriteDao.insertAllData(new FavoriteModel(model.id, model.urdu, model.english, model.math));
                holder.iv_favorite.setImageResource(R.drawable.ic_favorite);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView urdu;
        public TextView english;
        public TextView math;
        public ImageView iv_favorite;

        public ViewHolder(View view) {
            super(view);
            iv_favorite = view.findViewById(R.id.iv_favorite);
            urdu = view.findViewById(R.id.urdu);
            english = view.findViewById(R.id.english);
            math = view.findViewById(R.id.math);

        }
    }
}
