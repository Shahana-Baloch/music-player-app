package com.socialpps.myfavbuttonrecycler.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "favorite_table", indices = {@Index(value = {"urdu"}, unique = true), @Index(value = {"english"}, unique = true),@Index(value = {"math"}, unique = true)})
public class FavoriteModel {

    @ColumnInfo(name = "urdu")
    public String urdu;

    @ColumnInfo(name = "english")
    public String english;

    @ColumnInfo(name = "math")
    public String math;


    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    public int id;

    public FavoriteModel(int id, String urdu, String english,String math) {
        this.id = id;
        this.urdu = urdu;
        this.english = english;
        this.math = math;
    }
}
