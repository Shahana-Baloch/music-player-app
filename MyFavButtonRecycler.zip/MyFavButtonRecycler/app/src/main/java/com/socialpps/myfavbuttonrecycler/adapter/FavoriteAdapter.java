package com.socialpps.myfavbuttonrecycler.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.socialpps.myfavbuttonrecycler.R;
import com.socialpps.myfavbuttonrecycler.ui.FavoriteDao;
import com.socialpps.myfavbuttonrecycler.model.FavoriteModel;

import java.util.List;

public class FavoriteAdapter extends RecyclerView.Adapter<FavoriteAdapter.ViewHolder> {

    public final Context context;
    private final List<FavoriteModel> list;
    private final DeleteItemClickListner deleteItemClickListner;
    private final FavoriteDao mFavoriteDao;

    public FavoriteAdapter(Context context, FavoriteDao favoriteDao, List<FavoriteModel> list, DeleteItemClickListner deleteItemClickListner) {
        this.context = context;
        this.mFavoriteDao = favoriteDao;
        this.list = list;
        this.deleteItemClickListner = deleteItemClickListner;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        FavoriteModel model = list.get(position);

        holder.urdu.setText(model.urdu);
        holder.english.setText(model.english);
        holder.math.setText(model.math);
        //holder.english.setText(String.valueOf(model.id));

        boolean isFavorite = mFavoriteDao.isFavorite(model.id);
        if (isFavorite) {
            holder.iv_favorite.setImageResource(R.drawable.ic_favorite);
        } else {
            holder.iv_favorite.setImageResource(R.drawable.ic_favorite_border);
        }

        holder.iv_favorite.setOnClickListener(view -> deleteItemClickListner.onItemDelete(position, list.get(position).id));

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public interface DeleteItemClickListner {
        void onItemDelete(int position, int id);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView urdu;
        public TextView english;
        public TextView math;
        public ImageView iv_favorite;

        public ViewHolder(View view) {
            super(view);

            iv_favorite = view.findViewById(R.id.iv_favorite);
            urdu = view.findViewById(R.id.urdu);
            english = view.findViewById(R.id.english);
            math = view.findViewById(R.id.math);
        }
    }
}
