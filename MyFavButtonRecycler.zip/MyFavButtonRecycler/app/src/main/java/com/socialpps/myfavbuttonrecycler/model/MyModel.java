package com.socialpps.myfavbuttonrecycler.model;

public class MyModel {

    public int id;
    public String urdu;
    public String english;
    public String math;

    public MyModel(int id, String urdu, String english,String math) {
        this.id = id;
        this.urdu = urdu;
        this.english = english;
        this.math=math;
    }

}
