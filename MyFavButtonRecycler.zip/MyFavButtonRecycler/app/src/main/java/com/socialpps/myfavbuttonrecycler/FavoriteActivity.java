package com.socialpps.myfavbuttonrecycler;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.socialpps.myfavbuttonrecycler.adapter.FavoriteAdapter;
import com.socialpps.myfavbuttonrecycler.ui.FavoriteDao;
import com.socialpps.myfavbuttonrecycler.ui.FavoriteDatabase;
import com.socialpps.myfavbuttonrecycler.model.FavoriteModel;

import java.util.List;

public class FavoriteActivity extends AppCompatActivity {

    private FavoriteDao mFavoriteDao;
    private RecyclerView recyclerview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);
        recyclerview = findViewById(R.id.recyclerview);


        FavoriteDatabase db = FavoriteDatabase.getDatabase(this);
        mFavoriteDao = db.getDao();

    }

    @Override
    protected void onResume() {
        super.onResume();
        getData();
    }

    private void getData() {
        List<FavoriteModel> list = FavoriteDatabase.getDatabase(getApplicationContext()).getDao().getAllData();


        recyclerview.setLayoutManager(new LinearLayoutManager(this));
        recyclerview.setAdapter(new FavoriteAdapter(getApplicationContext(), mFavoriteDao, list, new FavoriteAdapter.DeleteItemClickListner() {
            @Override
            public void onItemDelete(int position, int id) {
                FavoriteDatabase.getDatabase(getApplicationContext()).getDao().deleteData(id);
                getData();
            }
        }));

        ImageView emptyImage = findViewById(R.id.empty_image);
        if (list.isEmpty()) {
            emptyImage.setVisibility(View.VISIBLE);
        }
        else {
            emptyImage.setVisibility(View.GONE);
        }
    }

}