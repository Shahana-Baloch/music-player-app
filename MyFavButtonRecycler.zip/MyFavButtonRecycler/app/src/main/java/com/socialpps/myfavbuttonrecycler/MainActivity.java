package com.socialpps.myfavbuttonrecycler;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.socialpps.myfavbuttonrecycler.adapter.MyAdapter;
import com.socialpps.myfavbuttonrecycler.model.MyModel;
import com.socialpps.myfavbuttonrecycler.ui.FavoriteDao;
import com.socialpps.myfavbuttonrecycler.ui.FavoriteDatabase;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private FavoriteDao mFavoriteDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FavoriteDatabase db = FavoriteDatabase.getDatabase(this);
        mFavoriteDao = db.getDao();

        Button save = findViewById(R.id.btn_getData);
        save.setOnClickListener(view -> startActivity(new Intent(getApplicationContext(), FavoriteActivity.class)));

        getData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        getData();
    }

    private void getData() {
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<MyModel> list = new ArrayList<>();
        list.add(new MyModel(1, "Urdu text here", "english text here","math1"));
        list.add(new MyModel(2, "Urdu text2 here", "english text2 here","math2"));
        list.add(new MyModel(3, "Urdu text3 here", "english text3 here","math3"));
        list.add(new MyModel(4, "Urdu text4 here", "english text4 here","math4"));
        list.add(new MyModel(5, "Urdu text5 here", "english text5 here","math5"));
        list.add(new MyModel(6, "Urdu text6 here", "english text6 here","math6"));
        list.add(new MyModel(7, "Urdu text7 here", "english text7 here","math7"));

        MyAdapter adapter = new MyAdapter(list, mFavoriteDao);
        recyclerView.setAdapter(adapter);


    }

}
