package com.weatherapps.weatherappkotlin

data class Clouds(
    val all: Int
)